﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Flippy.Dac.Model
{
    public class FlippyModel
    {
        [BsonId]
        public ObjectId InternalId { get; set; }
        public string CustomerId { get; set; }
        public string OrderId { get; set; }
        public string Content { get; set; }
    }
}
