﻿using Flippy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Flippy.Dac
{
    public interface IFlippyRepository
    {
        Task<string> InsertCustomerOrder(CustomerOrder customerOrder);

        Task<CustomerOrder> GetCustomerOrder(string orderId, string customerId);

        Task<List<CustomerOrder>> GetAllCustomerOrders(string customerId);

        Task<bool> UpdateCustomerOrder(string orderId, string customerId, string status, string reason = null);
    }
}
