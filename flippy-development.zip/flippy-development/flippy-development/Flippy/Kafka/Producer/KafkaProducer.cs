﻿using Confluent.Kafka;
using Flippy.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Flippy.Kafka.Producer
{
    public class KafkaProducer : IKafkaProducer, IDisposable
    {
        private IProducer<string, string> producer;
        private Topic _topic;

        public KafkaProducer(IConfiguration configuration, Topic topic)
        {
            this._topic = topic;

            var producerConfig = new ProducerConfig();
            configuration.Bind("producer", producerConfig);

            this.producer = new ProducerBuilder<string, string>(producerConfig).Build();
        }

        private async Task SendMessage(string message, string topic, string key)
        {
            await this.producer.ProduceAsync(topic, new Message<string, string> { Value = message, Key = key });
        }

        public async Task SendCustomerOrderToShop(CustomerOrder order)
        {
            var shopOrder = new
            {
                ShopId = order.ShopId,
                ShopName = order.ShopName,
                Order = new
                {
                    CustomerId = order.CustomerId,
                    CustomerName = order.CustomerName,
                    CustomerAddress = order.CustomerAddress,
                    CustomerContact = order.CustomerContact,
                    OrderId = order.Order.OrderId,
                    ItemName = order.Order.ItemName,
                    Quantity = order.Order.Quantity,
                    Status = "Order Placed"
                }
            };
            await SendMessage(JsonConvert.SerializeObject(shopOrder), _topic.Shop, "1");
        }

        public void Dispose()
        {
            this.producer.Dispose();
        }
    }
}
