﻿using Flippy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Flippy.Kafka.Producer
{
    public interface IKafkaProducer
    {
        Task SendCustomerOrderToShop(CustomerOrder order);
    }
}
