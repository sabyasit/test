﻿using Confluent.Kafka;
using Flippy.Dac;
using Flippy.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Flippy.Kafka.Consumer
{
    public class KafkaConsumer : IKafkaConsumer, IDisposable
    {
        private IFlippyRepository _flippyRepository;
        private IConsumer<string, string> consumer;
        private Topic _topic;

        public KafkaConsumer(IConfiguration configuration, IFlippyRepository flippyRepository, Topic topic)
        {
            _topic = topic;
            _flippyRepository = flippyRepository;

            var consumerConfig = new ConsumerConfig();
            configuration.Bind("consumer", consumerConfig);

            consumer = new ConsumerBuilder<string, string>(consumerConfig).Build();
        }

        public async Task ReadMessage(CancellationToken cancellationToken)
        {
            if (consumer.Subscription.Count == 0)
                consumer.Subscribe(_topic.Flippy);

            var consumeResult = this.consumer.Consume(cancellationToken);

            if (consumeResult.Message != null && consumeResult.Message.Value != null)
            {
                await ProcessMessage(consumeResult.Message.Value, consumeResult.Message.Key);
            }
        }

        private async Task ProcessMessage(string message, string key)
        {
            if (key == "1")
            {
                var order = JsonConvert.DeserializeObject<CustomerOrder>(message);

                await _flippyRepository.UpdateCustomerOrder(order.Order.OrderId, order.CustomerId, order.Order.Status, order.Order.RejectReason);
            }
        }

        public void Dispose()
        {
            this.consumer.Dispose();
        }
    }
}
