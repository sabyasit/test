﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Flippy.ExceptionHandler
{
    public class ApiException : System.Exception
    {
        public int StatusCode { get; set; }
        public string ErrorMsg { get; set; }
        public ApiException(int statusCode, string errorMsg) : base(errorMsg)
        {
            this.StatusCode = statusCode;
            this.ErrorMsg = errorMsg;
        }
    }
}
