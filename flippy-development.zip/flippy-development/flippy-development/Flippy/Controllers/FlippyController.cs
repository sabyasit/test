﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Flippy.Dac;
using Flippy.ExceptionHandler;
using Flippy.Kafka;
using Flippy.Kafka.Producer;
using Flippy.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Flippy.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FlippyController : ControllerBase
    {
        private IFlippyRepository _flippyRepository;
        private IKafkaProducer _kafkaProducer;

        public FlippyController(IFlippyRepository flippyRepository, IKafkaProducer kafkaProducer)
        {
            _flippyRepository = flippyRepository;
            _kafkaProducer = kafkaProducer;
        }

        /// <summary>
        /// Get all Customer Orders (paginated) (Returns: CustomerOrder List)
        /// </summary>
        /// <param name="customerId">CustomerId that need to be considered for filter</param>
        /// <param name="perPage">Number of items per page</param>
        /// <param name="page">The index of page to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">CustomerId not supplied</response>
        /// <response code="404">Customer order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpGet]
        [Route("/api/orders")]
        public async Task<ApiResponse> GetOrders([FromQuery] string customerId, [FromQuery] int? perPage, [FromQuery] int? page)
        {
            if (string.IsNullOrEmpty(customerId))
                throw new ApiException(StatusCodes.Status400BadRequest, "CustomerId not supplied");

            var orders = await _flippyRepository.GetAllCustomerOrders(customerId);

            if (orders == null || orders.Count == 0)
                throw new ApiException(StatusCodes.Status404NotFound, "Customer order not found");

            int totalRecords = 0;
            int totalPages = 0;

            if (orders.Count > 0)
            {
                totalRecords = orders.Count;
                if (perPage.HasValue)
                    totalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(totalRecords) / Convert.ToDouble(perPage.Value)));

                if (perPage.HasValue && page.HasValue)
                {
                    if (orders.Count > (perPage.Value * (page.Value - 1)))
                    {
                        orders = orders.Skip((page.Value - 1) * perPage.Value).Take(perPage.Value).ToList();
                    }
                    else
                    {
                        orders.Clear();
                        totalPages = 0;
                    }
                }
            }

            Response.Headers.Add("X-Total", totalRecords.ToString());
            Response.Headers.Add("X-Total-Pages", totalPages.ToString());
            Response.Headers.Add("X-Per-Page", (perPage.HasValue ? perPage.Value : 0).ToString());
            Response.Headers.Add("X-Page", (page.HasValue ? page.Value : 0).ToString());

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString(),
                Data = orders
            };
        }

        /// <summary>
        /// Get specific Customer Order (Returns: CustomerOrder)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="customerId">CustomerId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">Invalid OrderId</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpGet]
        [Route("/api/orders/{orderId}")]
        public async Task<ApiResponse> GetOrder([FromRoute] string orderId, [FromQuery] string customerId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var order = await _flippyRepository.GetCustomerOrder(orderId, customerId);

            if(order==null)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString(),
                Data = order
            };
        }

        /// <summary>
        /// Place order (Returns: CustomerOrder)
        /// </summary>
        /// <param name="body">CustomerOrder object</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">Invalid Customer Order</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpPost]
        [Route("/api/orders")]
        public async Task<ApiResponse> CreateOrder(CustomerOrder order)
        {
            if (order == null)
                throw new ApiException(StatusCodes.Status400BadRequest, "Invalid Customer Order");

            var orderId = await _flippyRepository.InsertCustomerOrder(order);

            order.Order.OrderId = orderId;
            await _kafkaProducer.SendCustomerOrderToShop(order);

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString(),
                Data = new
                {
                    OrderId = orderId
                }
            };
        }
    }
}
