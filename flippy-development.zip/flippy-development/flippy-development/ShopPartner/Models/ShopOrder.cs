﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopPartner.Models
{
    public class ShopOrder
    {
        public string ShopId { get; set; }
        public string ShopName { get; set; }
        public string AgentId { get; set; }
        public CustomerOrder Order { get; set; }
    }
}
