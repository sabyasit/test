﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopPartner.Dac.Config
{
    public class DbConfig
    {
        public string Database { get; set; }
        public string Server { get; set; }
        public int Port { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public string Collection { get; set; }

        public string ConnectionString
        {
            get
            {
                return string.Format(@"mongodb://{0}:{1}@{2}:{3}", User, Password, Server, Port);
            }
        }
    }
}
