﻿using ShopPartner.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopPartner.Dac
{
    public interface IShopRepository
    {
        Task<List<ShopOrder>> GetAllShopOrder(string shopId);
        Task<ShopOrder> GetShopOrder(string orderId, string shopId);
        Task<bool> UpdateOrderStatus(string orderId, string shopId, string status, string reason);
        Task<bool> InsertShopOrder(ShopOrder order);
    }
}
