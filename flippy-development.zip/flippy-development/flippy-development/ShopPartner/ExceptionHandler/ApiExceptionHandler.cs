﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using ShopPartner.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopPartner.ExceptionHandler
{
    public static class ApiExceptionHandler
    {
        public static void ConfigureApiExceptionHandler(this IApplicationBuilder app)
        {
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {
                    var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();

                    if (exceptionHandlerPathFeature != null)
                    {
                        var exception = exceptionHandlerPathFeature.Error;
                        if (exception != null && exception.GetType() == typeof(ApiException))
                        {
                            var apiException = exception as ApiException;
                            context.Response.StatusCode = apiException.StatusCode;
                            context.Response.ContentType = "application/json";
                            await context.Response.WriteAsync(JsonConvert.SerializeObject(new ApiResponse()
                            {
                                Status = ApiResponseStatus.Failed.ToString(),
                                Message = apiException.ErrorMsg
                            }));
                        }
                        else
                        {
                            context.Response.StatusCode = (int)StatusCodes.Status500InternalServerError;
                            context.Response.ContentType = "application/json";
                            await context.Response.WriteAsync(JsonConvert.SerializeObject(new ApiResponse()
                            {
                                Status = ApiResponseStatus.Failed.ToString(),
                                Message = "Internal Server Error."
                            }));
                        }
                    }
                });
            });
        }
    }
}
