﻿using ShopPartner.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopPartner.Kafka.Producer
{
    public interface IKafkaProducer
    {
        Task SendCustomerOrderAcceptStatus(ShopOrder order);
        Task SendCustomerOrderRejectStatus(ShopOrder order);
        Task SendShopOrderToAgent(ShopOrder order);
        Task SendAgentOrderReadyStatus(ShopOrder order);
    }
}
