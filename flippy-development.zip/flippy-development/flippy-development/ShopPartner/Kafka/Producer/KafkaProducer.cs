﻿using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using ShopPartner.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ShopPartner.Kafka.Producer
{
    public class KafkaProducer : IKafkaProducer, IDisposable
    {
        private IProducer<string, string> producer;
        private Topic _topic;

        public KafkaProducer(IConfiguration configuration, Topic topic)
        {
            this._topic = topic;

            var producerConfig = new ProducerConfig();
            configuration.Bind("producer", producerConfig);

            this.producer = new ProducerBuilder<string, string>(producerConfig).Build();
        }

        private async Task SendMessage(string message, string topic, string key)
        {
            await this.producer.ProduceAsync(topic, new Message<string, string> { Value = message, Key = key });
        }

        public async Task SendCustomerOrderAcceptStatus(ShopOrder order)
        {
            var customerOrder = new
            {
                CustomerId = order.Order.CustomerId,
                ShopId = order.ShopId,
                Order = new
                {
                    OrderId = order.Order.OrderId,
                    Status = order.Order.Status,
                    RejectReason = order.Order.RejectReason
                }
            };
            await SendMessage(JsonConvert.SerializeObject(customerOrder), _topic.Flippy, "1");
        }

        public async Task SendCustomerOrderRejectStatus(ShopOrder order)
        {
            var customerOrder = new
            {
                CustomerId = order.Order.CustomerId,
                ShopId = order.ShopId,
                Order = new
                {
                    OrderId = order.Order.OrderId,
                    Status = order.Order.Status,
                    RejectReason = order.Order.RejectReason
                }
            };
            await SendMessage(JsonConvert.SerializeObject(customerOrder), _topic.Flippy, "1");
        }

        public async Task SendShopOrderToAgent(ShopOrder order)
        {
            var agentOrder = new
            {
                AgentId = order.AgentId,
                CustomerId = order.Order.CustomerId,
                CustomerName = order.Order.CustomerName,
                CustomerAddress = order.Order.CustomerAddress,
                CustomerContact = order.Order.CustomerContact,
                ShopId = order.ShopId,
                OrderId = order.Order.OrderId,
                Status = "Delivery Requested"
            };
            await SendMessage(JsonConvert.SerializeObject(agentOrder), _topic.Agent, "1");
        }

        public async Task SendAgentOrderReadyStatus(ShopOrder order)
        {
            var agentOrder = new
            {
                AgentId = order.AgentId,
                OrderId = order.Order.OrderId,
                Status = "Order Ready"
            };
            await SendMessage(JsonConvert.SerializeObject(agentOrder), _topic.Agent, "2");
        }

        public void Dispose()
        {
            this.producer.Dispose();
        }
    }
}
