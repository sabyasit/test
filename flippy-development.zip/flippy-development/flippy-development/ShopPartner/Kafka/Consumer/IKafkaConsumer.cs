﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ShopPartner.Kafka.Consumer
{
    public interface IKafkaConsumer
    {
        Task ReadMessage(CancellationToken cancellationToken);
    }
}
