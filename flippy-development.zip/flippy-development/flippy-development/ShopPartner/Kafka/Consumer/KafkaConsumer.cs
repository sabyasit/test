﻿using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using ShopPartner.Dac;
using ShopPartner.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ShopPartner.Kafka.Consumer
{
    public class KafkaConsumer : IKafkaConsumer, IDisposable
    {
        private IShopRepository _shopRepository;
        private IConsumer<string, string> consumer;
        private Topic _topic;

        public KafkaConsumer(IConfiguration configuration, IShopRepository shopRepository, Topic topic)
        {
            _topic = topic;
            _shopRepository = shopRepository;

            var consumerConfig = new ConsumerConfig();
            configuration.Bind("consumer", consumerConfig);

            consumer = new ConsumerBuilder<string, string>(consumerConfig).Build();
        }

        public async Task ReadMessage(CancellationToken cancellationToken)
        {
            if (consumer.Subscription.Count == 0)
                consumer.Subscribe(_topic.Shop);

            var consumeResult = this.consumer.Consume(cancellationToken);

            if(consumeResult.Message !=null && consumeResult.Message.Value != null)
            {
                await ProcessMessage(consumeResult.Message.Value, consumeResult.Message.Key);
            }
        }

        private async Task ProcessMessage(string message, string key)
        {
            if(key == "1")
            {
                var order = JsonConvert.DeserializeObject<ShopOrder>(message);
                order.Order.Status = "Order Received";

                await _shopRepository.InsertShopOrder(order);
            }
        }

        public void Dispose()
        {
            this.consumer.Dispose();
        }
    }
}
