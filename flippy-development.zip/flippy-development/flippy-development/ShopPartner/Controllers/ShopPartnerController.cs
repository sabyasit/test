﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShopPartner.Dac;
using ShopPartner.ExceptionHandler;
using ShopPartner.Kafka.Producer;
using ShopPartner.Models;

namespace ShopPartner.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ShopPartnerController : ControllerBase
    {
        private IShopRepository _shopRepository;
        private IKafkaProducer _kafkaProducer;

        public ShopPartnerController(IShopRepository shopRepository, IKafkaProducer kafkaProducer)
        {
            _shopRepository = shopRepository;
            _kafkaProducer = kafkaProducer;
        }

        /// <summary>
        /// Get all Shop Orders (paginated) (Returns: ShopOrder List)
        /// </summary>
        /// <param name="shopId">ShopId that need to be considered for filter</param>
        /// <param name="perPage">Number of items per page</param>
        /// <param name="page">The index of page to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">ShopId not supplied</response>
        /// <response code="404">Shop order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpGet]
        [Route("/api/shop/orders")]
        public async Task<ApiResponse> GetOrders([FromQuery] string shopId, [FromQuery] int? perPage, [FromQuery] int? page)
        {
            if (string.IsNullOrEmpty(shopId))
                throw new ApiException(StatusCodes.Status400BadRequest, "ShopId not supplied");

            var orders = await _shopRepository.GetAllShopOrder(shopId);

            if (orders == null || orders.Count == 0)
                throw new ApiException(StatusCodes.Status404NotFound, "Shop order not found");

            int totalRecords = 0;
            int totalPages = 0;

            if (orders.Count > 0)
            {
                totalRecords = orders.Count;
                if (perPage.HasValue)
                    totalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(totalRecords) / Convert.ToDouble(perPage.Value)));

                if (perPage.HasValue && page.HasValue)
                {
                    if (orders.Count > (perPage.Value * (page.Value - 1)))
                    {
                        orders = orders.Skip((page.Value - 1) * perPage.Value).Take(perPage.Value).ToList();
                    }
                    else
                    {
                        orders.Clear();
                        totalPages = 0;
                    }
                }
            }

            Response.Headers.Add("X-Total", totalRecords.ToString());
            Response.Headers.Add("X-Total-Pages", totalPages.ToString());
            Response.Headers.Add("X-Per-Page", (perPage.HasValue ? perPage.Value : 0).ToString());
            Response.Headers.Add("X-Page", (page.HasValue ? page.Value : 0).ToString());

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString(),
                Data = orders
            };
        }

        /// <summary>
        /// Get specific Shop Order (Returns: ShopOrder)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="shopId">ShopId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">OrderId not supplied</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpGet]
        [Route("/api/shop/orders/{orderId}")]
        public async Task<ApiResponse> GetOrder([FromRoute] string orderId, [FromQuery] string shopId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var order = await _shopRepository.GetShopOrder(orderId, shopId);

            if(order == null)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString(),
                Data = order
            };
        }

        /// <summary>
        /// Accept order (Returns: Shop Order accept status)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="shopId">ShopId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">OrderId not supplied</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpPut]
        [Route("/api/shop/orders/{orderId}/accept")]
        public async Task<ApiResponse> OrderAccept([FromRoute] string orderId, [FromQuery] string shopId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var status = await _shopRepository.UpdateOrderStatus(orderId, shopId, "Accept", null);

            if (status == false)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            var order = await _shopRepository.GetShopOrder(orderId, shopId);
            await _kafkaProducer.SendCustomerOrderAcceptStatus(order);
            await _kafkaProducer.SendShopOrderToAgent(order);

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString(),
                Data = new
                {
                    AgentId = order.AgentId
                }
            };
        }

        /// <summary>
        /// Reject order (Returns: Shop Order Reject status)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="shopId">ShopId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">OrderId not supplied</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpPut]
        [Route("/api/shop/orders/{orderId}/reject")]
        public async Task<ApiResponse> OrderReject([FromRoute] string orderId, [FromQuery] string shopId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var status = await _shopRepository.UpdateOrderStatus(orderId, shopId, "Reject", null);

            if (status == false)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            var order = await _shopRepository.GetShopOrder(orderId, shopId);
            await _kafkaProducer.SendCustomerOrderAcceptStatus(order);

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString()
            };
        }

        /// <summary>
        /// Order is ready (Returns: Shop Order Ready status)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="shopId">ShopId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">OrderId not supplied</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpPut]
        [Route("/api/shop/orders/{orderId}/ready")]
        public async Task<ApiResponse> OrderReady([FromRoute] string orderId, [FromQuery] string shopId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var status = await _shopRepository.UpdateOrderStatus(orderId, shopId, "Ready", null);

            if (status == false)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            var order = await _shopRepository.GetShopOrder(orderId, shopId);
            await _kafkaProducer.SendAgentOrderReadyStatus(order);

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString()
            };
        }
    }
}
