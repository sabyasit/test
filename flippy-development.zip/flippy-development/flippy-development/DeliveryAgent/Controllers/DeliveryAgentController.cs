﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DeliveryAgent.Dac;
using DeliveryAgent.ExceptionHandler;
using DeliveryAgent.Kafka.Producer;
using DeliveryAgent.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace DeliveryAgent.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DeliveryAgentController : ControllerBase
    {
        private IAgentRepository _agentRepository;
        private IKafkaProducer _kafkaProducer;

        public DeliveryAgentController(IAgentRepository agentRepository, IKafkaProducer kafkaProducer)
        {
            _agentRepository = agentRepository;
            _kafkaProducer = kafkaProducer;
        }

        /// <summary>
        /// Get all Agent Orders (paginated) (Returns: AgentOrder List)
        /// </summary>
        /// <param name="agentId">AgentId that need to be considered for filter</param>
        /// <param name="perPage">Number of items per page</param>
        /// <param name="page">The index of page to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">AgentId not supplied</response>
        /// <response code="404">Agent order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpGet]
        [Route("/api/delivery/orders")]
        public async Task<ApiResponse> GetOrders([FromQuery] string agentId, [FromQuery] int? perPage, [FromQuery] int? page)
        {
            if (string.IsNullOrEmpty(agentId))
                throw new ApiException(StatusCodes.Status400BadRequest, "AgentId not supplied");

            var orders = await _agentRepository.GetAllAgentOrder(agentId);

            if (orders == null || orders.Count == 0)
                throw new ApiException(StatusCodes.Status404NotFound, "Agent order not found");

            int totalRecords = 0;
            int totalPages = 0;

            if(orders.Count > 0)
            {
                totalRecords = orders.Count;
                if (perPage.HasValue)
                    totalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(totalRecords) / Convert.ToDouble(perPage.Value)));

                if (perPage.HasValue && page.HasValue)
                {
                    if (orders.Count > (perPage.Value * (page.Value - 1)))
                    {
                        orders = orders.Skip((page.Value - 1) * perPage.Value).Take(perPage.Value).ToList();
                    }
                    else
                    {
                        orders.Clear();
                        totalPages = 0;
                    }
                }
            }

            Response.Headers.Add("X-Total", totalRecords.ToString());
            Response.Headers.Add("X-Total-Pages", totalPages.ToString());
            Response.Headers.Add("X-Per-Page", (perPage.HasValue ? perPage.Value : 0).ToString());
            Response.Headers.Add("X-Page", (page.HasValue ? page.Value : 0).ToString());

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString(),
                Data = orders
            };
        }

        /// <summary>
        /// Get specific Agent Order (Returns: AgentOrder)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="agentId">AgentId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">OrderId not supplied</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpGet]
        [Route("/api/delivery/orders/{orderId}")]
        public async Task<ApiResponse> GetOrder([FromRoute] string orderId, [FromQuery] string agentId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var order = await _agentRepository.GetAgentOrder(orderId, agentId);

            if (order == null)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString(),
                Data = order
            };
        }

        /// <summary>
        /// Arrived at Shop (Returns: Agent Arrived status)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="agentId">AgentId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">OrderId not supplied</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpPut]
        [Route("/api/delivery/orders/{orderId}/arrive")]
        public async Task<ApiResponse> OrderArrive([FromRoute] string orderId, [FromQuery] string agentId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var status = await _agentRepository.UpdateOrderStatus(orderId, agentId, "Arrive", null);

            if (status == false)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            var order = await _agentRepository.GetAgentOrder(orderId, agentId);
            await _kafkaProducer.SendCustomerOrderAgentArriveStatus(order);

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString()
            };
        }

        /// <summary>
        /// Picked up Delivery (Returns: Agent Pickup Status)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="agentId">AgentId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">OrderId not supplied</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpPut]
        [Route("/api/delivery/orders/{orderId}/pickup")]
        public async Task<ApiResponse> OrderPickup([FromRoute] string orderId, [FromQuery] string agentId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var status = await _agentRepository.UpdateOrderStatus(orderId, agentId, "pickup", null);

            if (status == false)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            var order = await _agentRepository.GetAgentOrder(orderId, agentId);
            await _kafkaProducer.SendCustomerOrderPickedUpStatus(order);

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString()
            };
        }

        /// <summary>
        /// Order Delivered (Returns: Agent Delivered status)
        /// </summary>
        /// <param name="orderId">ID of Order to return</param>
        /// <param name="agentId">AgentId that need to be considered for filter</param>
        /// <response code="200">Successful operation</response>
        /// <response code="400">OrderId not supplied</response>
        /// <response code="404">Order not found</response>
        /// <response code="500">Internal Server Error.</response>
        [HttpPut]
        [Route("/api/delivery/orders/{orderId}/deliver")]
        public async Task<ApiResponse> OrderDeliver([FromRoute] string orderId, [FromQuery] string agentId)
        {
            if (string.IsNullOrEmpty(orderId))
                throw new ApiException(StatusCodes.Status400BadRequest, "OrderId not supplied");

            var status = await _agentRepository.UpdateOrderStatus(orderId, agentId, "deliver", null);

            if (status == false)
                throw new ApiException(StatusCodes.Status404NotFound, "Order not found");

            var order = await _agentRepository.GetAgentOrder(orderId, agentId);
            await _kafkaProducer.SendCustomerOrderDeliveredStatus(order);

            return new ApiResponse()
            {
                Status = ApiResponseStatus.Success.ToString()
            };
        }
    }
}
