using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DeliveryAgent.Dac;
using DeliveryAgent.Dac.Config;
using DeliveryAgent.ExceptionHandler;
using DeliveryAgent.Kafka;
using DeliveryAgent.Kafka.Consumer;
using DeliveryAgent.Kafka.Producer;
using DeliveryAgent.Service;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace DeliveryAgent
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var dbconfig = new DbConfig();
            Configuration.GetSection("MongoDBConfig").Bind(dbconfig);
            var repository = new AgentRepository(dbconfig);
            services.AddSingleton<IAgentRepository>(repository);

            var topic = new Topic();
            Configuration.GetSection("Topic").Bind(topic);
            services.AddSingleton(topic);

            services.AddSingleton<IKafkaProducer, KafkaProducer>();

            services.AddSingleton<IKafkaConsumer, KafkaConsumer>();

            services.AddHostedService<KafkaService>();

            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.ConfigureApiExceptionHandler();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
