﻿using DeliveryAgent.Dac.Config;
using DeliveryAgent.Dac.Model;
using DeliveryAgent.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryAgent.Dac
{
    public class AgentRepository : IAgentRepository
    {
        private readonly IMongoDatabase _db;
        private IMongoCollection<AgentModel> _agentCollection;

        public AgentRepository(DbConfig config)
        {
            var client = new MongoClient(config.ConnectionString);
            _db = client.GetDatabase(config.Database);
            _agentCollection = _db.GetCollection<AgentModel>(config.Collection);
        }
        
        public async Task<List<AgentOrder>> GetAllAgentOrder(string agentId)
        {
            var agentOrders = await _agentCollection.Find(x => x.AgentId == agentId).ToListAsync();

            return agentOrders.Select(x => Newtonsoft.Json.JsonConvert.DeserializeObject<AgentOrder>(x.Content)).ToList();
        }

        public async Task<AgentOrder> GetAgentOrder(string orderId, string agentId)
        {
            var agentOrder = await _agentCollection.Find(x => x.OrderId == orderId && (x.AgentId == agentId || string.IsNullOrEmpty(agentId))).FirstOrDefaultAsync();

            if (agentOrder != null)
            {
                return Newtonsoft.Json.JsonConvert.DeserializeObject<AgentOrder>(agentOrder.Content);
            }
            else
            {
                return null;
            }
        }

        public async Task<bool> InsertAgentOrder(AgentOrder order)
        {
            await _agentCollection.InsertOneAsync(new AgentModel()
            {
                AgentId = order.AgentId,
                ShopId = order.ShopId,
                CustomerId = order.CustomerId,
                OrderId = order.OrderId,
                Content = Newtonsoft.Json.JsonConvert.SerializeObject(order)
            });

            return true;
        }

        public async Task<bool> UpdateOrderStatus(string orderId, string agentId, string status, string reason)
        {
            var agentOrder = await _agentCollection.Find(x => x.OrderId == orderId && (x.AgentId == agentId || string.IsNullOrEmpty(agentId))).FirstOrDefaultAsync();
            if (agentOrder != null)
            {
                var order = Newtonsoft.Json.JsonConvert.DeserializeObject<AgentOrder>(agentOrder.Content);
                order.Status = status;
                agentOrder.Content = Newtonsoft.Json.JsonConvert.SerializeObject(order);

                var result = await _agentCollection.ReplaceOneAsync(x => x.OrderId == orderId, agentOrder);
                return result.IsAcknowledged && result.ModifiedCount > 0;
            }
            else
            {
                return false;
            }
        }
    }
}
