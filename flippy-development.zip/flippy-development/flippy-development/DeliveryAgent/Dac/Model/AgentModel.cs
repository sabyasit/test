﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryAgent.Dac.Model
{
    public class AgentModel
    {
        [BsonId]
        public ObjectId InternalId { get; set; }
        public string CustomerId { get; set; }
        public string OrderId { get; set; }
        public string ShopId { get; set; }
        public string AgentId { get; set; }
        public string Content { get; set; }
    }
}
