﻿using DeliveryAgent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryAgent.Dac
{
    public interface IAgentRepository
    {
        Task<List<AgentOrder>> GetAllAgentOrder(string agentId);
        Task<AgentOrder> GetAgentOrder(string orderId, string agentId);
        Task<bool> UpdateOrderStatus(string orderId, string agentId, string status, string reason);
        Task<bool> InsertAgentOrder(AgentOrder order);
    }
}
