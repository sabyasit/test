﻿using Confluent.Kafka;
using DeliveryAgent.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;


namespace DeliveryAgent.Kafka.Producer
{
    public class KafkaProducer : IKafkaProducer, IDisposable
    {
        private IProducer<string, string> producer;
        private Topic _topic;

        public KafkaProducer(IConfiguration configuration, Topic topic)
        {
            this._topic = topic;

            var producerConfig = new ProducerConfig();
            configuration.Bind("producer", producerConfig);

            this.producer = new ProducerBuilder<string, string>(producerConfig).Build();
        }

        private async Task SendMessage(string message, string topic, string key)
        {
            await this.producer.ProduceAsync(topic, new Message<string, string> { Value = message, Key = key });
        }

        public async Task SendCustomerOrderAgentArriveStatus(AgentOrder order)
        {
            var customerOrder = new
            {
                CustomerId = order.CustomerId,
                ShopId = order.ShopId,
                Order = new
                {
                    OrderId = order.OrderId,
                    Status = order.Status
                }
            };
            await SendMessage(JsonConvert.SerializeObject(customerOrder), _topic.Flippy, "1");
        }

        public async Task SendCustomerOrderDeliveredStatus(AgentOrder order)
        {
            var customerOrder = new
            {
                CustomerId = order.CustomerId,
                ShopId = order.ShopId,
                Order = new
                {
                    OrderId = order.OrderId,
                    Status = order.Status
                }
            };
            await SendMessage(JsonConvert.SerializeObject(customerOrder), _topic.Flippy, "1");
        }

        public async Task SendCustomerOrderPickedUpStatus(AgentOrder order)
        {
            var customerOrder = new
            {
                CustomerId = order.CustomerId,
                ShopId = order.ShopId,
                Order = new
                {
                    OrderId = order.OrderId,
                    Status = order.Status
                }
            };
            await SendMessage(JsonConvert.SerializeObject(customerOrder), _topic.Flippy, "1");
        }
        public void Dispose()
        {
            this.producer.Dispose();
        }
    }
}
