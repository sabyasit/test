﻿using DeliveryAgent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryAgent.Kafka.Producer
{
    public interface IKafkaProducer
    {
        Task SendCustomerOrderAgentArriveStatus(AgentOrder order);
        Task SendCustomerOrderPickedUpStatus(AgentOrder order);
        Task SendCustomerOrderDeliveredStatus(AgentOrder order);
    }
}
