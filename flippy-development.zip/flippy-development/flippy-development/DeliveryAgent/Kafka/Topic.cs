﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryAgent.Kafka
{
    public class Topic
    {
        public string Flippy { get; set; }
        public string Shop { get; set; }
        public string Agent { get; set; }
    }
}
