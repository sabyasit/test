﻿using Confluent.Kafka;
using DeliveryAgent.Dac;
using DeliveryAgent.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DeliveryAgent.Kafka.Consumer
{
    public class KafkaConsumer : IKafkaConsumer, IDisposable
    {
        private IAgentRepository _agentRepository;
        private IConsumer<string, string> consumer;
        private Topic _topic;

        public KafkaConsumer(IConfiguration configuration, IAgentRepository agentRepository, Topic topic)
        {
            _topic = topic;
            _agentRepository = agentRepository;

            var consumerConfig = new ConsumerConfig();
            configuration.Bind("consumer", consumerConfig);

            consumer = new ConsumerBuilder<string, string>(consumerConfig).Build();
        }

        public async Task ReadMessage(CancellationToken cancellationToken)
        {
            if (consumer.Subscription.Count == 0)
                consumer.Subscribe(_topic.Agent);

            var consumeResult = this.consumer.Consume(cancellationToken);

            if (consumeResult.Message != null && consumeResult.Message.Value != null)
            {
                await ProcessMessage(consumeResult.Message.Value, consumeResult.Message.Key);
            }
        }

        private async Task ProcessMessage(string message, string key)
        {
            if (key == "1") //New Order
            {
                var order = JsonConvert.DeserializeObject<AgentOrder>(message);
                await _agentRepository.InsertAgentOrder(order);
            }

            if (key == "2") //Order Ready
            {
                var order = JsonConvert.DeserializeObject<AgentOrder>(message);
                await _agentRepository.UpdateOrderStatus(order.OrderId, order.AgentId, order.Status, null);
            }
        }

        public void Dispose()
        {
            this.consumer.Dispose();
        }
    }
}
