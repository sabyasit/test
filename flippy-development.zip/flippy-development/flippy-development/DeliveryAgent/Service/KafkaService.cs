﻿using DeliveryAgent.Kafka.Consumer;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DeliveryAgent.Service
{
    public class KafkaService : BackgroundService
    {
        private IKafkaConsumer _kafkaConsumer;

        public KafkaService(IKafkaConsumer kafkaConsumer)
        {
            _kafkaConsumer = kafkaConsumer;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await Task.Run(() => ProcessMessage(stoppingToken));
        }

        private async Task ProcessMessage(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await _kafkaConsumer.ReadMessage(stoppingToken);
            }
        }
    }
}
