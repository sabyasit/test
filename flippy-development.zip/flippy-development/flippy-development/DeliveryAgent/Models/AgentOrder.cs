﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeliveryAgent.Models
{
    public class AgentOrder
    {
        public string AgentId { get; set; }
        public string AgentName { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerContact { get; set; }
        public string ShopId { get; set; }
        public string OrderId { get; set; }
        public string Status { get; set; } //arrived,pickup,delivered
    }
}
