# Flippy Deployment Procedure

#### Prerequisite
- Docker (Docker Desktop)
- Kubernetes (Enable Kubernetes in Docker Desktop)

#### Flippy Gateway Deployment
- **Step 1:** Open command prompt and go to path **[Source file location]/FlippyGateway** directory.
- **Step 2:** Execute command "**docker build -t flippygatewayapi:v1 .**" to build image.
- **Step 3:** Execute Command "**kubectl apply -f manifest-api.yml**" to deploy Gateway microservice and create kubernetes service.

#### Flippy Microservice Deployment
- **Step 1:** Open command prompt and go to path **[Source file location]/Flippy** directory.
- **Step 2:** Execute command "**docker build -t flippyapi:v1 .**" to build image.
- **Step 3:** Execute Command "**kubectl apply -f manifest-api.yml**" to deploy Flippy microservice and create kubernetes service.
- **Step 3:** Execute Command "**kubectl apply -f manifest-db.yml**" to deploy mongodb and create kubernetes service.

#### ShopPartner Microservice Deployment
- **Step 1:** Open command prompt and go to path **[Source file location]/ShopPartner** directory.
- **Step 2:** Execute command "**docker build -t shopapi:v1 .**" to build image.
- **Step 3:** Execute Command "**kubectl apply -f manifest-api.yml**" to deploy Flippy microservice and create kubernetes service.
- **Step 3:** Execute Command "**kubectl apply -f manifest-db.yml**" to deploy mongodb and create kubernetes service.
 
#### DeliveryAgent Microservice Deployment
- **Step 1:** Open command prompt and go to path **[Source file location]/DeliveryAgent** directory.
- **Step 2:** Execute command "**docker build -t agentapi:v1 .**" to build image.
- **Step 3:** Execute Command "**kubectl apply -f manifest-api.yml**" to deploy Flippy microservice and create kubernetes service.
- **Step 3:** Execute Command "**kubectl apply -f manifest-db.yml**" to deploy mongodb and create kubernetes service.

#### Kafka Broker Deployment 
- **Step 1:** Open command prompt and go to path **[Source file location]** directory.
- **Step 2:** Execute Command "**kubectl apply -f manifest-kafka.yml**" to deploy kafka broker and zookeeper and create services.

 **note:** After completion of all deployment, wait for sometime as images are downloading from dockerhub after that restart docker .

#### Deployment Status Check
- Open command prompt and execute command "**kubectl get pods**".
- Check status for all pods are running, if not running wait for sometime and then restart docker. 
 
#### Testing
- Open "**https://editor.swagger.io/**".
- Copy content of "**openapi.yaml**" from **[Source file location]** to swagger io editor.
- Select server to "**localhost:2560**" (localhost is accessible as Cors is enabled in gateway).
- Execute "**/api/Secretkey**" to get jwt token in response. 
- Add jwt token to Authorize section in swagger.
- Test all microservices.